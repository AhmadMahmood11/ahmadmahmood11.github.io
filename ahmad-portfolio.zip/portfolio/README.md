# Ahmad Chaudhary — Developer Portfolio

A high-quality personal portfolio website built with pure HTML, CSS, and JavaScript. Ready to deploy on GitHub Pages.

## 🚀 How to Deploy on GitHub Pages

1. **Upload these files to your GitHub repository**
   - Upload all files maintaining the folder structure:
     ```
     index.html
     css/style.css
     js/main.js
     README.md
     ```

2. **Enable GitHub Pages**
   - Go to your repository on GitHub
   - Click **Settings** → **Pages**
   - Under "Source", select **Deploy from a branch**
   - Choose **main** branch and **/ (root)** folder
   - Click **Save**

3. **Your site will be live at:**
   `https://yourusername.github.io/repository-name`

## 📁 File Structure

```
portfolio/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # All styles
├── js/
│   └── main.js         # Animations & interactions
└── README.md           # This file
```

## ✨ Features

- Dark theme with neon accent colors
- Custom animated cursor
- Scroll reveal animations
- Horizontal drag-scroll portfolio section
- Marquee text ticker
- Responsive design (mobile-friendly)
- Contact form with feedback
- Service cards with hover glow effect
- WhatsApp integration
- No dependencies — pure HTML/CSS/JS

## 📞 Contact

- **WhatsApp**: +92 303 355 7356
- **Email**: ahmad29chaudhary@gmail.com
